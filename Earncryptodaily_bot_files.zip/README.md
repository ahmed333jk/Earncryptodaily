# EarnCryptoDaily Telegram Bot

Starter Telegram bot for tasks, referrals, points and rewards.

## Features
- /start command
- Referral links
- Tasks menu
- Referral counter
- Points balance
- Rewards section
- Inline buttons

## Run locally

Install dependencies:

```bash
pip install -r requirements.txt
```

Set your Telegram bot token as an environment variable:

```bash
export BOT_TOKEN="YOUR_BOT_TOKEN"
```

Then run:

```bash
python bot.py
```

## Important
Do not put your real Telegram bot token directly in `bot.py` or upload it to GitHub.
Use an environment variable named `BOT_TOKEN`.

This starter version stores users in memory. If the process restarts, the data is reset.
For a production bot, use SQLite or PostgreSQL and add proper task verification and secure withdrawal logic.
